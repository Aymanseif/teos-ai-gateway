"""OpenAI Responses streaming primitives."""
